<?php
/**
 * Plugin Name: Photobook Pro — Woo Bridge
 * Description: REST bridge + admin UI pro brand looky, mapování na Woo, schválení a draft objednávky.
 * Version: 1.1.0
 * Author: Photobook Pro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PBP_Woo_Bridge {
  public function __construct(){
    add_action('rest_api_init', [$this,'routes']);
    add_action('admin_menu', [$this,'admin_menu']);
  }

  private function auth_check( $request ){
    if ( ! current_user_can('edit_products') ) {
      return new WP_Error('forbidden', 'Insufficient permissions', ['status'=>403]);
    }
    return true;
  }

  public function admin_menu(){
    add_menu_page('Photobook Pro','Photobook Pro','edit_products','pbp-bridge',[$this,'page_dashboard'],'dashicons-art',56);
    add_submenu_page('pbp-bridge','Brand looks','Brand looks','edit_products','pbp-looks',[$this,'page_looks']);
    add_submenu_page('pbp-bridge','Approvals','Approvals','edit_products','pbp-approvals',[$this,'page_approvals']);
  }
  public function page_dashboard(){
    echo '<div class="wrap"><h1>Photobook Pro — Bridge</h1><p>Napojení Studia na WooCommerce.</p></div>';
  }
  public function page_looks(){
    $payload = get_option('pbp_brand_looks_payload', ['looks'=>[], 'map'=>[]]);
    echo '<div class="wrap"><h1>Brand looks</h1><pre>'.esc_html( wp_json_encode($payload, JSON_PRETTY_PRINT) ).'</pre></div>';
  }
  public function page_approvals(){
    $ap = get_option('pbp_approvals', []);
    echo '<div class="wrap"><h1>Approvals</h1><table class="widefat"><thead><tr><th>Produkt</th><th>Jméno</th><th>Čas</th><th>Podpis</th></tr></thead><tbody>';
    if ( is_array($ap) ) {
      foreach($ap as $r){
        echo '<tr><td>'.esc_html($r['product']??'').'</td><td>'.esc_html($r['name']??'').'</td><td>'.esc_html($r['when']??'').'</td><td>';
        if ( !empty($r['signature']) ){
          echo '<img style="max-width:240px;border:1px solid #eee" src="'.esc_url($r['signature']).'">';
        }
        echo '</td></tr>';
      }
    }
    echo '</tbody></table></div>';
  }

  public function routes(){
    register_rest_route('pbp/v1','/looks', [
      [
        'methods'=>WP_REST_Server::READABLE,
        'callback'=>[$this,'get_looks'],
        'permission_callback'=>[$this,'auth_check']
      ],
      [
        'methods'=>WP_REST_Server::CREATABLE,
        'callback'=>[$this,'set_looks'],
        'permission_callback'=>[$this,'auth_check']
      ],
    ]);

    register_rest_route('pbp/v1','/approve', [
      'methods'=>WP_REST_Server::CREATABLE,
      'callback'=>[$this,'approve'],
      'permission_callback'=>[$this,'auth_check']
    ]);

    register_rest_route('pbp/v1','/prices', [
      'methods'=>WP_REST_Server::CREATABLE,
      'callback'=>[$this,'prices'],
      'permission_callback'=>[$this,'auth_check']
    ]);

    register_rest_route('pbp/v1','/order', [
      'methods'=>WP_REST_Server::CREATABLE,
      'callback'=>[$this,'create_order'],
      'permission_callback'=>[$this,'auth_check']
    ]);
  }

  public function get_looks( $request ){
    $data = get_option('pbp_brand_looks_payload', ['looks'=>[], 'map'=>[]]);
    return rest_ensure_response($data);
  }

  public function set_looks( $request ){
    $payload = json_decode( $request->get_body(), true );
    if ( ! is_array($payload) ) return new WP_Error('bad_request','Invalid body', ['status'=>400]);

    if ( isset($payload['map']['looks']) && is_array($payload['map']['looks']) ){
      $product_id = isset($payload['map']['productId']) ? intval($payload['map']['productId']) : 0;
      $variation_id = isset($payload['map']['variationId']) ? intval($payload['map']['variationId']) : 0;
      if ( function_exists('update_post_meta') && $product_id ){
        update_post_meta( $product_id, '_pbp_brand_looks', wp_json_encode( $payload['looks'] ) );
        if ( $variation_id ){
          update_post_meta( $variation_id, '_pbp_brand_looks', wp_json_encode( $payload['looks'] ) );
        }
      }
    }
    update_option('pbp_brand_looks_payload', $payload);
    return rest_ensure_response(['ok'=>true]);
  }

  public function approve( $request ){
    $payload = json_decode( $request->get_body(), true );
    if ( ! is_array($payload) ) return new WP_Error('bad_request','Invalid body', ['status'=>400]);

    $record = [
      'product' => sanitize_text_field($payload['product'] ?? 'default'),
      'name'    => sanitize_text_field($payload['name'] ?? ''),
      'when'    => sanitize_text_field($payload['when'] ?? current_time('mysql')),
      'signature' => $payload['signature'] ?? '',
      'ip'      => $_SERVER['REMOTE_ADDR'] ?? ''
    ];

    $all = get_option('pbp_approvals', []);
    if ( ! is_array($all) ) $all = [];
    $all[] = $record;
    update_option('pbp_approvals', $all);

    return rest_ensure_response(['ok'=>true, 'saved'=>count($all)]);
  }

  public function prices( $request ){
    if ( ! function_exists('wc_get_product') ) return new WP_Error('no_woo','WooCommerce not active', ['status'=>500]);
    $payload = json_decode( $request->get_body(), true );
    $pid = isset($payload['product']) ? intval($payload['product']) : 0;
    $vid = isset($payload['variation']) ? intval($payload['variation']) : 0;
    $qty = isset($payload['qty']) ? max(1, intval($payload['qty'])) : 1;
    $product = $vid ? wc_get_product($vid) : wc_get_product($pid);
    if ( ! $product ) return new WP_Error('not_found','Product not found', ['status'=>404]);
    $price = floatval( wc_get_price_to_display( $product, ['qty'=>$qty] ) );
    $currency = get_woocommerce_currency();
    return rest_ensure_response([ 'price'=>$price, 'currency'=>$currency, 'breakdown'=>[['label'=>'Base','value'=>$price]] ]);
  }

  public function create_order( $request ){
    if ( ! function_exists('wc_create_order') ) return new WP_Error('no_woo','WooCommerce not active', ['status'=>500]);
    $payload = json_decode( $request->get_body(), true );
    $pid = isset($payload['productId']) ? intval($payload['productId']) : 0;
    $vid = isset($payload['variationId']) ? intval($payload['variationId']) : 0;
    $qty = isset($payload['qty']) ? max(1, intval($payload['qty'])) : 1;
    $preview = $payload['preview'] ?? '';
    $project = isset($payload['project']) ? (array)$payload['project'] : [];
    $pricing = isset($payload['pricing']) ? (array)$payload['pricing'] : [];

    $order = wc_create_order();
    if ( $vid ){
      $order->add_product( wc_get_product($vid), $qty );
    } else {
      $order->add_product( wc_get_product($pid), $qty );
    }
    $order->update_status('pending', 'Created from Photobook Pro Studio');
    $order_id = $order->get_id();

    if ( $project ){
      update_post_meta($order_id, '_pbp_project', wp_json_encode($project));
    }
    if ( $pricing ){
      update_post_meta($order_id, '_pbp_pricing', wp_json_encode($pricing));
    }
    // Attach preview image if provided (dataURL)
    if ( $preview && preg_match('#^data:image/\w+;base64,#', $preview) ){
      $upload_dir = wp_upload_dir();
      $data = base64_decode( preg_replace('#^data:image/\w+;base64,#', '', $preview) );
      $file = trailingslashit($upload_dir['path']).'pbp-preview-'.time().'.png';
      file_put_contents($file, $data);
      $filetype = wp_check_filetype( basename($file), null );
      $attach_id = wp_insert_attachment([
        'post_mime_type' => $filetype['type'],
        'post_title' => 'PBP Preview',
        'post_content' => '',
        'post_status' => 'inherit'
      ], $file, $order_id);
      require_once( ABSPATH . 'wp-admin/includes/image.php' );
      $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
      wp_update_attachment_metadata( $attach_id, $attach_data );
      add_post_meta( $order_id, '_pbp_preview_id', $attach_id, true );
      $order->add_order_note('Photobook Pro přiložil náhled.');
    }

    return rest_ensure_response(['ok'=>true, 'order_id'=>$order_id]);
  }
}

new PBP_Woo_Bridge();
